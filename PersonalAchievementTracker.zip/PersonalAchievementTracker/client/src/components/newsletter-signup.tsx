import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function NewsletterSignup() {
  const [email, setEmail] = useState("");
  const [isHovered, setIsHovered] = useState(false);
  const { toast } = useToast();
  
  const subscribeNewsletterMutation = useMutation({
    mutationFn: async (email: string) => {
      const res = await apiRequest("POST", "/api/newsletter/subscribe", { email });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscription successful",
        description: "You have been subscribed to our newsletter.",
      });
      setEmail("");
    },
    onError: (error: Error) => {
      toast({
        title: "Subscription failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Email required",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }
    
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }
    
    subscribeNewsletterMutation.mutate(email);
  };

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.7 }}
      className="p-8 md:p-12 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 rounded-2xl mx-6 md:mx-10 mb-10 relative overflow-hidden shadow-2xl"
    >
      {/* Background embellishments */}
      <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-blue-500/10 rounded-full blur-3xl transform -translate-x-1/4 -translate-y-1/4"></div>
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-purple-500/10 rounded-full blur-3xl transform translate-x-1/4 translate-y-1/4"></div>
      
      {/* Floating coin elements */}
      <div className="absolute top-10 right-10 w-16 h-16 rounded-full bg-blue-500/30 backdrop-blur-md animate-float hidden md:block"></div>
      <div className="absolute bottom-10 left-10 w-12 h-12 rounded-full bg-purple-500/30 backdrop-blur-md animate-float-slow hidden md:block"></div>
      
      {/* Content */}
      <div className="max-w-6xl mx-auto text-center relative z-10">
        <div className="inline-block bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full mb-4 shadow-lg">
          VIP Access
        </div>
        
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 tracking-tight">
          Never Miss an <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">Airdrop Opportunity</span>
        </h2>
        
        <p className="text-blue-100 mb-8 max-w-2xl mx-auto text-lg">
          Subscribe to our notification service and be the first to know about new airdrops, testnets, and exclusive token distributions.
        </p>
        
        <motion.form 
          onSubmit={handleSubmit} 
          className="relative max-w-xl mx-auto"
          initial={{ scale: 1 }}
          animate={{ scale: isHovered ? 1.02 : 1 }}
          transition={{ duration: 0.2 }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="flex flex-col sm:flex-row items-center justify-center p-2 bg-white/10 backdrop-blur-md rounded-full border border-white/20 shadow-xl">
            <div className="flex items-center flex-1 pl-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-300 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <Input 
                type="email" 
                placeholder="Enter your email address" 
                className="bg-transparent border-none shadow-none text-white placeholder:text-blue-200/70 focus:ring-0 w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={subscribeNewsletterMutation.isPending}
              />
            </div>
            <Button 
              type="submit" 
              variant="default"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-2 px-6 rounded-full shadow-lg transition-all duration-300 w-full sm:w-auto"
              disabled={subscribeNewsletterMutation.isPending}
            >
              {subscribeNewsletterMutation.isPending ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Subscribing...
                </span>
              ) : "Get Early Access"}
            </Button>
          </div>
        </motion.form>
        
        <div className="mt-6 flex justify-center items-center space-x-8 text-blue-200 text-sm">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span>Secure & Private</span>
          </div>
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            <span>Unsubscribe Anytime</span>
          </div>
        </div>
      </div>
    </motion.section>
  );
}
