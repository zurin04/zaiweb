import axios from "axios";

// Interface for cryptocurrency prices
interface CryptoPrice {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  price_change_percentage_24h: number;
}

// Cache configuration
const CACHE_TTL = 60 * 1000; // 1 minute
let cachedPrices: CryptoPrice[] | null = null;
let lastFetched: number = 0;

export async function getCryptoPrices(): Promise<CryptoPrice[]> {
  const now = Date.now();
  
  // Return cached data if it's fresh
  if (cachedPrices && now - lastFetched < CACHE_TTL) {
    return cachedPrices;
  }
  
  try {
    // Fetch top 10 cryptocurrencies by market cap
    const response = await axios.get(
      "https://api.coingecko.com/api/v3/coins/markets", 
      {
        params: {
          vs_currency: "usd",
          order: "market_cap_desc",
          per_page: 10,
          page: 1,
          sparkline: false,
          price_change_percentage: "24h"
        }
      }
    );
    
    // Update cache
    cachedPrices = response.data;
    lastFetched = now;
    
    return cachedPrices;
  } catch (error) {
    // If API call fails and we have cached data, return it even if it's stale
    if (cachedPrices) {
      console.error("Error fetching crypto prices, using stale cache:", error);
      return cachedPrices;
    }
    
    // If we have no cached data, throw the error
    console.error("Error fetching crypto prices:", error);
    throw new Error("Failed to fetch cryptocurrency prices");
  }
}
